/* pam_authuser module */

/*
 * Copyright (c) 2004 The University of New Mexico (UNM)
 *
 * Created by The Center for High Performance Computing at The University
 * of New Mexico.
 *
 * Authors: Shawn Sustaita, Jim Prewett <download@hpcerc.unm.edu>
 * Version: 0.1.1
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include <string.h>
#include <syslog.h>
#include <security/_pam_macros.h>

#define PAM_SM_ACCOUNT
#include <security/pam_modules.h>
#include <stdio.h>

#define NETGROUP_STR "netgroup"
#define AUTHUSER_STR "authuser"
#define NOAUTHUSER_STR "noauthuser"

/* external functions */
extern ssize_t 
getline(char **lineptr, size_t *n, FILE *stream);

extern int
innetgr(const char *netgroup, const char *host, const char *user, const char *domain);

char **
build_netgroups(char **argv, int argc, int *count);

char **
list_authuser_files(char **argv, int argc, int *count);

char **
list_authusers(char **files, int file_count, int *count);

/* --- session management functions --- */

PAM_EXTERN int 
pam_sm_acct_mgmt(pam_handle_t *pamh, int flags, int argc, const char **argv){

	/* the name of the user and the service that user is connecting to */
	const char * user, * service, * ruser;

	int i; /* cannonical counter int */
	int retval = PAM_SESSION_ERR; /* the value to return; default is error */

	char **netgroups = NULL;	/* to hold the list of netgroups */
	int netgroup_count = 0;

	char **authuser_file_list = NULL; /* to hold the list of authuser files*/
	int authuser_file_count = 0;
	
	char **noauthuser_file_list = NULL; /* to hold the list of noauthuser files*/
	int noauthuser_file_count = 0;

	char **authusers = NULL;	  /* to hold the list of authorized users */
	int authuser_count = 0;

	pam_get_item(pamh, PAM_SERVICE, (const void **) &service); /* what service is being requested? */
	openlog(service, LOG_PID, LOG_USER);

	/* find out who is asking for the session */
	if ( pam_get_item(pamh, PAM_USER, (const void **) &user) != PAM_SUCCESS ) {
		syslog(LOG_INFO, "%s", "pam_get_item failed (PAM_USER)\n");
		goto bail;
	}

	/* we always allow root */
	if(!strcmp(user,"root")){
		retval = PAM_SUCCESS;
		goto bail;
		}

	/* root can do whatever he likes... really */
	/* root had better have already authenticated properly */
	if(pam_get_item(pamh, PAM_RUSER, (const void **) &ruser) == PAM_SUCCESS){
		if(ruser){
			if(!strcmp(ruser,"root")){
				retval = PAM_SUCCESS;
				goto bail;
			}
		}
	}

	/* build the list of netgroups to always allow */
	netgroups = build_netgroups((char **)argv,argc,&netgroup_count);

	/* build the list of files containing the authorized users */
	authuser_file_list = list_authuser_files((char **)argv,argc,&authuser_file_count);
	
	/* build the list of files containing the explicitly unauthorized users */
	noauthuser_file_list = list_noauthuser_files((char **)argv,argc,&noauthuser_file_count);

	/* build the list of authorized users from authuser_file_list */
	authusers = list_authusers(authuser_file_list,authuser_file_count, &authuser_count);

	for(i = 0; i < netgroup_count; i++){
		/* see if the user is in an allowed netgroup */
		if(innetgr(netgroups[i], NULL, user, NULL)){
			retval = PAM_SUCCESS;
			goto bail;
		}
	}

	for(i = 0; i < authuser_count; i++){
		if(!strcmp(user,authusers[i])){
			retval = PAM_SUCCESS;
			goto bail;
		}
	}

	goto bail;

/* clean up our mess and quit; return whatever retval says */
bail:

	/* free our malloc()'d memory */
	for(i = 0; i < authuser_count; i++){
		free(authusers[i]);
	}
	free(authusers);

	for(i = 0; i < authuser_file_count; i++){
		free(authuser_file_list[i]);
	}
	free(authuser_file_list);

	for(i = 0; i < netgroup_count; i++){
		free(netgroups[i]);
	}
	free(netgroups);

	closelog();
	return retval;
}

/* return an array of allowed netgroups */
char **
build_netgroups(char **argv, int argc, int *count){
	int i = 0;
	char **netgroups = NULL;
	for(i = 0; i < argc; i++){
		if(!strncmp(NETGROUP_STR,argv[i],strlen(NETGROUP_STR))){
			(*count)++;
			netgroups = realloc(netgroups, (sizeof(char *) * *count));
			netgroups[(*count) - 1] = (argv[i] + strlen(NETGROUP_STR) + 1);
			if(!(netgroups[(*count) - 1])){
				syslog(LOG_INFO,"not enough memory!\n");
				(*count)--;
				goto fail;
				}
			}
		}
	return(netgroups);
fail:
	free(netgroups);
	netgroups = NULL;
	return(netgroups);
	}

/* return an array of authusers */
char **
list_authusers(char **files, int file_count, int *count){
	int i = 0;
	char **allowed_users = NULL;
	char *potential_authuser = NULL;
	char *position = NULL;  /* where to stop looking for an authusername */
	int n = 0;
	FILE *file = NULL;

	/* XXX this loop could be cleaned up a bit */
	for(i = 0; i < file_count ; i++){
		if((file = fopen(files[i],"r"))){
		/* download hacking -- mostly ripped from my authuser patch */
		/* see if they are in the authuser file, if so allow them, else deny them */
			while(getline(&potential_authuser,&n,file) != -1){
	  	 /* allow for extra whitespace, 
		 		* and optional comments after first whitespace
		 		*
		 		* Throw away all of that nonsense... 
		 		*/
	  		position = strpbrk(potential_authuser,"\n\t ");
				if(position){
								/* put a null there and ignore the rest of the string */
								*position = '\0';
				}

				(*count)++;

				allowed_users = realloc(allowed_users, (sizeof(char *) * (*count)));
				allowed_users[((*count) - 1)] = strdup(potential_authuser);
			}
			fclose(file);
		}
		else{
			syslog(LOG_INFO,"can't open file: %s\n",files[i]);
		}
	}
	return(allowed_users);
}

/* return an array of authuser files */
char **
list_authuser_files(char **argv, int argc, int *count){
	int i = 0;
	char **authusers = NULL;
	for(i = 0; i < argc; i++){
		if(!strncmp(AUTHUSER_STR,argv[i],strlen(AUTHUSER_STR))){
			(*count)++;
			authusers = realloc(authusers, (sizeof(char *) * *count));
			authusers[(*count) - 1] = (argv[i] + strlen(AUTHUSER_STR) + 1);
			if(!(authusers[(*count) - 1])){
				syslog(LOG_INFO,"not enough memory!\n");
				(*count)--;
				goto fail;
				}
			}
		}
	return(authusers);
fail:
	free(authusers);
	authusers = NULL;
	return(authusers);
	}

/* return an array of noauthuser files */
char **
list_noauthuser_files(char **argv, int argc, int *count){
	int i = 0;
	char **noauthusers = NULL;
	for(i = 0; i < argc; i++){
		if(!strncmp(NOAUTHUSER_STR,argv[i],strlen(NOAUTHUSER_STR))){
			(*count)++;
			noauthusers = realloc(noauthusers, (sizeof(char *) * *count));
			noauthusers[(*count) - 1] = (argv[i] + strlen(NOAUTHUSER_STR) + 1);
			if(!(noauthusers[(*count) - 1])){
				syslog(LOG_INFO,"not enough memory!\n");
				(*count)--;
				goto fail;
				}
			}
		}
	return(noauthusers);
fail:
	free(noauthusers);
	authusers = NULL;
	return(noauthusers);
	}

#ifdef PAM_STATIC

/* static module data */
/* XXX does this work?  Haven't tested a static build yet */

struct pam_module _pam_authuser_modstruct = {
     "pam_authuser",
     NULL,
     NULL,
     pam_sm_acct_mgmt,
     NULL,
     NULL,
     NULL,
};

#endif
